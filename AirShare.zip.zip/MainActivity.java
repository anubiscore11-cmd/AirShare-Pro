package com.airshare.pro;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.airshare.pro.services.TransferService;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "AirSharePro";

    // ─── Codes de requête ───────────────────────────────────────────────
    private static final int REQUEST_PERMISSIONS_CODE   = 1001;
    private static final int REQUEST_FILE_PICKER        = 1002;
    private static final int REQUEST_BLUETOOTH_ENABLE   = 1003;
    private static final int REQUEST_WIFI_ENABLE        = 1004;
    private static final int REQUEST_NOTIFICATION_PERM  = 1005;

    // ─── WebView & UI ───────────────────────────────────────────────────
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    // ─── Système ────────────────────────────────────────────────────────
    private BluetoothAdapter bluetoothAdapter;
    private WifiManager wifiManager;
    private Vibrator vibrator;
    private Handler mainHandler;

    // ─── Permissions Android 13+ ────────────────────────────────────────
    private static final String[] PERMISSIONS_ANDROID_13 = {
        Manifest.permission.BLUETOOTH_SCAN,
        Manifest.permission.BLUETOOTH_CONNECT,
        Manifest.permission.BLUETOOTH_ADVERTISE,
        Manifest.permission.NEARBY_WIFI_DEVICES,
        Manifest.permission.READ_MEDIA_IMAGES,
        Manifest.permission.READ_MEDIA_VIDEO,
        Manifest.permission.READ_MEDIA_AUDIO,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.POST_NOTIFICATIONS
    };

    private static final String[] PERMISSIONS_ANDROID_12 = {
        Manifest.permission.BLUETOOTH_SCAN,
        Manifest.permission.BLUETOOTH_CONNECT,
        Manifest.permission.BLUETOOTH_ADVERTISE,
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.ACCESS_FINE_LOCATION
    };

    private static final String[] PERMISSIONS_LEGACY = {
        Manifest.permission.BLUETOOTH,
        Manifest.permission.BLUETOOTH_ADMIN,
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE,
        Manifest.permission.ACCESS_FINE_LOCATION
    };

    // ─── BroadcastReceiver pour les changements d'état Bluetooth ────────
    private final BroadcastReceiver bluetoothStateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (BluetoothAdapter.ACTION_STATE_CHANGED.equals(intent.getAction())) {
                int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR);
                String jsState = (state == BluetoothAdapter.STATE_ON) ? "on" : "off";
                runOnUiThread(() -> webView.evaluateJavascript(
                    "window.onBluetoothStateChanged && window.onBluetoothStateChanged('" + jsState + "');",
                    null
                ));
            }
        }
    };

    // ════════════════════════════════════════════════════════════════════
    //  LIFECYCLE
    // ════════════════════════════════════════════════════════════════════

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mainHandler = new Handler(Looper.getMainLooper());

        configureSystemUI();
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        initVibrator();

        configureWebView();
        loadUI();
        requestAllPermissions();
        registerReceivers();

        handleIncomingShare(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIncomingShare(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        webView.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(bluetoothStateReceiver); } catch (Exception ignored) {}
        if (webView != null) {
            webView.removeAllViews();
            webView.destroy();
        }
    }

    // ════════════════════════════════════════════════════════════════════
    //  CONFIGURATION UI SYSTÈME (AMOLED / Edge-to-Edge)
    // ════════════════════════════════════════════════════════════════════

    private void configureSystemUI() {
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);

        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.setSystemBarsAppearance(0,
                    WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS |
                    WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
            }
        }

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    // ════════════════════════════════════════════════════════════════════
    //  CONFIGURATION WEBVIEW
    // ════════════════════════════════════════════════════════════════════

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private void configureWebView() {
        WebSettings settings = webView.getSettings();

        // JavaScript & stockage
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        // Performances 120Hz
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setRenderPriority(WebSettings.RenderPriority.HIGH);
        settings.setMediaPlaybackRequiresUserGesture(false);

        // Encoding & zoom
        settings.setDefaultTextEncodingName("UTF-8");
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        // Mixed content pour réseau local
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        // Accélération matérielle
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        webView.setBackgroundColor(Color.BLACK);

        // Désactiver le scrollbar
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);

        // Interface JavaScript → Java
        webView.addJavascriptInterface(new WebInterface(), "Android");

        // WebViewClient : interception de navigation
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    if (!url.contains("localhost") && !url.contains("127.0.0.1") && !url.contains("192.168.")) {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                        return true;
                    }
                }
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                injectSystemInfo();
            }
        });

        // WebChromeClient : gestion sélecteur de fichiers
        webView.setWebChromeClient(new WebChromeClient() {

            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                Log.d(TAG, "[WebConsole] " + consoleMessage.message()
                    + " — " + consoleMessage.sourceId()
                    + ":" + consoleMessage.lineNumber());
                return true;
            }

            // Android 5.0+ — méthode principale
            @Override
            public boolean onShowFileChooser(WebView webView,
                                             ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                cancelExistingFileCallback();
                MainActivity.this.filePathCallback = filePathCallback;

                Intent contentSelectionIntent = new Intent(Intent.ACTION_GET_CONTENT);
                contentSelectionIntent.addCategory(Intent.CATEGORY_OPENABLE);
                contentSelectionIntent.setType("*/*");
                contentSelectionIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);

                // Proposer aussi le gestionnaire de fichiers système
                Intent[] intentArray;
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                    intentArray = new Intent[]{ takePictureIntent };
                } else {
                    intentArray = new Intent[0];
                }

                Intent chooserIntent = new Intent(Intent.ACTION_CHOOSER);
                chooserIntent.putExtra(Intent.EXTRA_INTENT, contentSelectionIntent);
                chooserIntent.putExtra(Intent.EXTRA_TITLE, "Sélectionner des fichiers");
                chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, intentArray);

                startActivityForResult(chooserIntent, REQUEST_FILE_PICKER);
                return true;
            }
        });
    }

    private void cancelExistingFileCallback() {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
    }

    private void loadUI() {
        webView.loadUrl("file:///android_asset/index.html");
    }

    // ════════════════════════════════════════════════════════════════════
    //  PERMISSIONS
    // ════════════════════════════════════════════════════════════════════

    private void requestAllPermissions() {
        String[] permissions;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions = PERMISSIONS_ANDROID_13;
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissions = PERMISSIONS_ANDROID_12;
        } else {
            permissions = PERMISSIONS_LEGACY;
        }

        List<String> toRequest = new ArrayList<>();
        for (String perm : permissions) {
            if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                toRequest.add(perm);
            }
        }

        if (!toRequest.isEmpty()) {
            ActivityCompat.requestPermissions(this,
                toRequest.toArray(new String[0]),
                REQUEST_PERMISSIONS_CODE);
        } else {
            onAllPermissionsGranted();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS_CODE) {
            boolean allGranted = true;
            List<String> denied = new ArrayList<>();
            for (int i = 0; i < grantResults.length; i++) {
                if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    denied.add(permissions[i]);
                }
            }
            if (allGranted) {
                onAllPermissionsGranted();
            } else {
                Log.w(TAG, "Permissions refusées : " + denied);
                notifyPermissionsStatus(false, denied);
            }
        }
    }

    private void onAllPermissionsGranted() {
        notifyPermissionsStatus(true, new ArrayList<>());
    }

    private void notifyPermissionsStatus(boolean granted, List<String> denied) {
        try {
            JSONObject payload = new JSONObject();
            payload.put("granted", granted);
            JSONArray deniedArr = new JSONArray();
            for (String d : denied) deniedArr.put(d.replace("android.permission.", ""));
            payload.put("denied", deniedArr);
            String js = "window.onPermissionsResult && window.onPermissionsResult(" + payload.toString() + ");";
            runOnUiThread(() -> webView.evaluateJavascript(js, null));
        } catch (Exception e) {
            Log.e(TAG, "notifyPermissionsStatus error", e);
        }
    }

    // ════════════════════════════════════════════════════════════════════
    //  ACTIVITY RESULT — Sélecteur de fichiers
    // ════════════════════════════════════════════════════════════════════

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_FILE_PICKER) {
            if (filePathCallback == null) return;

            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                String dataString = data.getDataString();
                ClipData clipData = data.getClipData();

                if (clipData != null) {
                    results = new Uri[clipData.getItemCount()];
                    for (int i = 0; i < clipData.getItemCount(); i++) {
                        results[i] = clipData.getItemAt(i).getUri();
                    }
                } else if (dataString != null) {
                    results = new Uri[]{ Uri.parse(dataString) };
                }

                // Notifier le JS avec les métadonnées du fichier sélectionné
                if (results != null && results.length > 0) {
                    notifyFileSelected(results);
                }
            }

            filePathCallback.onReceiveValue(results);
            filePathCallback = null;

        } else if (requestCode == REQUEST_BLUETOOTH_ENABLE) {
            boolean btOn = resultCode == Activity.RESULT_OK;
            runOnUiThread(() -> webView.evaluateJavascript(
                "window.onBluetoothEnableResult && window.onBluetoothEnableResult(" + btOn + ");",
                null
            ));
        }
    }

    private void notifyFileSelected(Uri[] uris) {
        try {
            JSONArray filesArray = new JSONArray();
            for (Uri uri : uris) {
                JSONObject fileObj = new JSONObject();
                String name = getFileName(uri);
                long size = getFileSize(uri);
                String mime = getMimeType(uri);
                fileObj.put("name", name);
                fileObj.put("size", size);
                fileObj.put("sizeFormatted", formatFileSize(size));
                fileObj.put("mime", mime);
                fileObj.put("uri", uri.toString());
                filesArray.put(fileObj);
            }
            String js = "window.onFilesSelected && window.onFilesSelected(" + filesArray.toString() + ");";
            runOnUiThread(() -> webView.evaluateJavascript(js, null));
        } catch (Exception e) {
            Log.e(TAG, "notifyFileSelected error", e);
        }
    }

    // ════════════════════════════════════════════════════════════════════
    //  JAVASCRIPT INTERFACE
    // ════════════════════════════════════════════════════════════════════

    public class WebInterface {

        @JavascriptInterface
        public boolean isBluetoothEnabled() {
            return bluetoothAdapter != null && bluetoothAdapter.isEnabled();
        }

        @JavascriptInterface
        public void enableBluetooth() {
            runOnUiThread(() -> {
                if (bluetoothAdapter == null) return;
                if (!bluetoothAdapter.isEnabled()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                        ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.BLUETOOTH_CONNECT)
                            == PackageManager.PERMISSION_GRANTED) {
                        Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                        startActivityForResult(enableBtIntent, REQUEST_BLUETOOTH_ENABLE);
                    } else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
                        Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                        startActivityForResult(enableBtIntent, REQUEST_BLUETOOTH_ENABLE);
                    }
                }
            });
        }

        @JavascriptInterface
        public boolean isWifiEnabled() {
            return wifiManager != null && wifiManager.isWifiEnabled();
        }

        @JavascriptInterface
        public void enableWifi() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q && wifiManager != null) {
                    wifiManager.setWifiEnabled(true);
                } else {
                    Intent panelIntent = new Intent(android.provider.Settings.Panel.ACTION_WIFI);
                    startActivity(panelIntent);
                }
            });
        }

        @JavascriptInterface
        public String getDeviceInfo() {
            try {
                JSONObject info = new JSONObject();
                info.put("model", Build.MODEL);
                info.put("manufacturer", Build.MANUFACTURER);
                info.put("sdk", Build.VERSION.SDK_INT);
                info.put("android", Build.VERSION.RELEASE);
                info.put("device", Build.DEVICE);
                info.put("brand", Build.BRAND);
                info.put("bluetooth", bluetoothAdapter != null && bluetoothAdapter.isEnabled());
                info.put("wifi", wifiManager != null && wifiManager.isWifiEnabled());
                if (bluetoothAdapter != null &&
                    ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.BLUETOOTH_CONNECT)
                        == PackageManager.PERMISSION_GRANTED) {
                    info.put("btName", bluetoothAdapter.getName());
                }
                return info.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public String getLocalIpAddress() {
            try {
                if (wifiManager != null) {
                    int ipInt = wifiManager.getConnectionInfo().getIpAddress();
                    return String.format("%d.%d.%d.%d",
                        (ipInt & 0xff),
                        (ipInt >> 8 & 0xff),
                        (ipInt >> 16 & 0xff),
                        (ipInt >> 24 & 0xff));
                }
            } catch (Exception e) {
                Log.e(TAG, "getLocalIpAddress", e);
            }
            return "0.0.0.0";
        }

        @JavascriptInterface
        public void vibrate(int durationMs) {
            if (vibrator == null) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vibrator.vibrate(durationMs);
            }
        }

        @JavascriptInterface
        public void vibratePattern(String type) {
            if (vibrator == null) return;
            long[] pattern;
            switch (type) {
                case "success": pattern = new long[]{0, 50, 50, 50}; break;
                case "error":   pattern = new long[]{0, 100, 50, 100, 50, 100}; break;
                case "tap":     pattern = new long[]{0, 30}; break;
                default:        pattern = new long[]{0, 50}; break;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1));
            } else {
                vibrator.vibrate(pattern, -1);
            }
        }

        @JavascriptInterface
        public void openFileManager() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                startActivityForResult(Intent.createChooser(intent, "Sélectionner des fichiers"), REQUEST_FILE_PICKER);
            });
        }

        @JavascriptInterface
        public boolean hasPermission(String permission) {
            String fullPerm = "android.permission." + permission;
            return ContextCompat.checkSelfPermission(MainActivity.this, fullPerm)
                == PackageManager.PERMISSION_GRANTED;
        }

        @JavascriptInterface
        public void requestPermissions() {
            runOnUiThread(() -> MainActivity.this.requestAllPermissions());
        }

        @JavascriptInterface
        public void startTransferService(String fileUri, String mode, String targetAddress) {
            runOnUiThread(() -> {
                Intent serviceIntent = new Intent(MainActivity.this, TransferService.class);
                serviceIntent.putExtra("fileUri", fileUri);
                serviceIntent.putExtra("mode", mode);
                serviceIntent.putExtra("targetAddress", targetAddress);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(serviceIntent);
                } else {
                    startService(serviceIntent);
                }
            });
        }

        @JavascriptInterface
        public void showToast(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
        }

        @JavascriptInterface
        public void openSettings() {
            runOnUiThread(() -> {
                Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                intent.setData(Uri.fromParts("package", getPackageName(), null));
                startActivity(intent);
            });
        }
    }

    // ════════════════════════════════════════════════════════════════════
    //  UTILITAIRES
    // ════════════════════════════════════════════════════════════════════

    @SuppressWarnings("deprecation")
    private void initVibrator() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            VibratorManager vm = (VibratorManager) getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
            if (vm != null) vibrator = vm.getDefaultVibrator();
        } else {
            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        }
    }

    private void registerReceivers() {
        IntentFilter btFilter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
        registerReceiver(bluetoothStateReceiver, btFilter);
    }

    private void injectSystemInfo() {
        String js = "window.AIRSHARE_NATIVE = true;" +
            "window.ANDROID_SDK = " + Build.VERSION.SDK_INT + ";" +
            "window.DEVICE_MODEL = '" + Build.MODEL.replace("'", "\\'") + "';";
        webView.evaluateJavascript(js, null);
    }

    private void handleIncomingShare(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (Intent.ACTION_SEND.equals(action)) {
            Uri fileUri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (fileUri != null) {
                notifyFileSelected(new Uri[]{ fileUri });
            }
        } else if (Intent.ACTION_SEND_MULTIPLE.equals(action)) {
            ArrayList<Uri> uris = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (uris != null && !uris.isEmpty()) {
                notifyFileSelected(uris.toArray(new Uri[0]));
            }
        }
    }

    private String getFileName(Uri uri) {
        String result = null;
        if ("content".equals(uri.getScheme())) {
            try (android.database.Cursor cursor = getContentResolver().query(
                    uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (idx != -1) result = cursor.getString(idx);
                }
            } catch (Exception ignored) {}
        }
        if (result == null) {
            result = uri.getPath();
            if (result != null) {
                int cut = result.lastIndexOf('/');
                if (cut != -1) result = result.substring(cut + 1);
            }
        }
        return result != null ? result : "fichier_inconnu";
    }

    private long getFileSize(Uri uri) {
        try (android.database.Cursor cursor = getContentResolver().query(
                uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.SIZE);
                if (idx != -1 && !cursor.isNull(idx)) return cursor.getLong(idx);
            }
        } catch (Exception ignored) {}
        return 0L;
    }

    private String getMimeType(Uri uri) {
        String mime = getContentResolver().getType(uri);
        if (mime == null) {
            String ext = MimeTypeMap.getFileExtensionFromUrl(uri.toString());
            if (ext != null) mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase());
        }
        return mime != null ? mime : "application/octet-stream";
    }

    private String formatFileSize(long bytes) {
        if (bytes <= 0) return "0 o";
        final String[] units = {"o", "Ko", "Mo", "Go", "To"};
        int idx = (int) (Math.log10(bytes) / Math.log10(1024));
        idx = Math.min(idx, units.length - 1);
        double value = bytes / Math.pow(1024, idx);
        DecimalFormat df = new DecimalFormat("#,##0.#");
        return df.format(value) + " " + units[idx];
    }
}
